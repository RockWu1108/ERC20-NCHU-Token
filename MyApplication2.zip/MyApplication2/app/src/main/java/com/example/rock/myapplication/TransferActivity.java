package com.example.rock.myapplication;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import org.web3j.crypto.Credentials;
import org.web3j.crypto.RawTransaction;
import org.web3j.crypto.TransactionEncoder;
import org.web3j.protocol.admin.Admin;
import org.web3j.protocol.core.DefaultBlockParameter;
import org.web3j.protocol.core.DefaultBlockParameterName;
import org.web3j.protocol.core.methods.response.EthGetBalance;
import org.web3j.protocol.core.methods.response.EthGetTransactionCount;
import org.web3j.protocol.core.methods.response.EthSendTransaction;
import org.web3j.protocol.http.HttpService;
import org.web3j.utils.Convert;
import org.web3j.utils.Numeric;

import java.io.IOException;
import java.math.BigInteger;
import java.util.EnumMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;

public class TransferActivity extends AppCompatActivity  {
    EditText edAccount ;
    EditText edAmount ;
    Button btn_wallet_qrcode;
    Button btn_transfer;
    Button btn_update;
    ImageView ivw_QR;
    ImageView img_wallet_qrcode;
    TextView txbalance;
    TextView txaddr;
    Credentials credentials;
    FixedSupplyToken token;
    private IntentIntegrator scanIntegrator;
    private ProgressDialog dialog;
    Dialog mydialog;
    ImageView qrcode_dialog_img;
    int blanceETH;
    String address;


    //BigInteger GAS_PRICE = BigInteger.valueOf(0);
    //BigInteger GAS_LIMIT = BigInteger.valueOf(4_300_000);
    //String contractAddr = "0xb559CB6a0402304f7C9A25F4CceAAFfe306e0631";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transfer);
        MainActivity.admin = Admin.build(new HttpService("http://140.120.55.86:8545"));//連線到Server
        credentials = Credentials.create("a0b62ca6eb7db17fe0d03c65d1fc1c9ffe27256abf530688a0ea21b47136788e");
        System.out.println("pk:"+credentials.getEcKeyPair().getPrivateKey().toString(16));
        address= credentials.getAddress();
       // address="0x8597A5AE400B91ce9C2b26026916Ea2E4a5e1731";
        try
        {
            setid();
            //getBlanceOf(address);
            setting_contract();
            contract_getbalance();

        }
        catch (Exception e)
        {

        }

    }

    //元件設定
    public void setid(){
        edAccount =findViewById(R.id.ed_account);
        edAmount =  findViewById(R.id.ed_amount);
        btn_update =findViewById(R.id.btn_update);
        btn_transfer =  findViewById(R.id.btn_tansfer);
        btn_wallet_qrcode = findViewById(R.id.btn_wallet_QRCODE);
        txbalance=findViewById(R.id.tx_blanceof);
        ivw_QR = findViewById(R.id.qr_image);
        img_wallet_qrcode = findViewById(R.id.img_wallet_qrcode);
        txaddr = findViewById(R.id.tx_fromaddr);
        txaddr.setText("帳戶位址："+address);

        ivw_QR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scanIntegrator = new IntentIntegrator(TransferActivity.this);
                scanIntegrator.setPrompt("請掃描");
                scanIntegrator.setTimeout(300000);
                scanIntegrator.initiateScan();
            }
        });
        btn_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    contract_getbalance();
                    //getBlanceOf(address);
                } catch (Exception e) {

                }
            }
        });
        btn_transfer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(TransferActivity.this);
                builder.setMessage("是否轉帳？")
                        .setPositiveButton("是", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                //transcation(edAccount.getText().toString());
                                contract_transfer(edAccount.getText().toString());

                            }
                        })
                        .setNegativeButton("否", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });
                AlertDialog about_dialog = builder.create();
                about_dialog.show();

            }

        });
        btn_wallet_qrcode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                create_qrcode();
            }
        });
    }

    //產生錢包地址QRcode
    public void create_qrcode(){
        BarcodeEncoder encoder = new BarcodeEncoder();
        try {
            Map hints = new EnumMap(EncodeHintType.class);
            hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
            Bitmap bit = encoder.encodeBitmap(credentials.getAddress(), BarcodeFormat.QR_CODE, 500, 500,hints);
            //img_wallet_qrcode.setImageBitmap(bit);
            qrcode_image(bit);

        } catch (WriterException e) {
            e.printStackTrace();
        }
    }

    //產生qrcode_dialog
    private void qrcode_image(Bitmap bit){
    mydialog = new Dialog(TransferActivity.this);
    mydialog.setContentView(R.layout.qrcode_dialog_image);
    qrcode_dialog_img = mydialog.findViewById(R.id.qrcode_image);
    qrcode_dialog_img.setImageBitmap(bit);
    mydialog.show();
    }

    //以太幣帳戶間轉帳交易
    private void transcation(String toAccount){
        BigInteger GAS_PRICE = BigInteger.valueOf(0);
        BigInteger GAS_LIMIT = BigInteger.valueOf(4_300_000);
      //  String address_to = "0x5b02d2123a00c46ea22047c3142BE20B2c6aab65";

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    //Credentials credentials = Credentials.create("a0b62ca6eb7db17fe0d03c65d1fc1c9ffe27256abf530688a0ea21b47136788e");
//                    Credentials credentials = WalletUtils.loadCredentials("123456",
//                            "/storage/emulated/0/Download/UTC--2019-05-28T09-32-35.0Z--9cdc6de0952107e3973e4dcb56cc1e0c8d2a850f.json");
                    System.out.println("Address:"+credentials.getAddress());
                    EthGetTransactionCount ethGetTransactionCount =MainActivity.admin.ethGetTransactionCount(
                            credentials.getAddress(), DefaultBlockParameterName.LATEST).sendAsync().get();


                    BigInteger nonce = ethGetTransactionCount.getTransactionCount();
                    //创建交易，这里是转0.5个以太币
                    BigInteger value = Convert.toWei(edAmount.getText().toString(), Convert.Unit.ETHER).toBigInteger();
                    RawTransaction rawTransaction = RawTransaction.createEtherTransaction(
                            nonce, GAS_PRICE, GAS_LIMIT, toAccount, value);

                    //交易簽章
                    byte[] signedMessage = TransactionEncoder.signMessage(rawTransaction, credentials);
                    String hexValue = Numeric.toHexString(signedMessage);

                    //发送交易
                    EthSendTransaction ethSendTransaction =MainActivity.admin.ethSendRawTransaction(hexValue).sendAsync().get();
                    String transactionHash = ethSendTransaction.getTransactionHash();
                    System.out.println("txhash:"+transactionHash);

                }  catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }
            }
        }).start();

    }

    //以太幣餘額查詢
    private void getBlanceOf(String address) throws IOException {

        new Thread(new Runnable() {
            @Override
            public void run() {
                if (MainActivity.admin == null) return;
                //String address = "0x9cdc6de0952107e3973e4dcb56cc1e0c8d2a850f";
                //第二个参数：区块的参数，建议选最新区块
                EthGetBalance balance = null;
                try {
                    balance = MainActivity.admin.ethGetBalance(address, DefaultBlockParameter.valueOf("latest")).send();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                //格式转化 wei-ether
                //BigDecimal 轉 int
                blanceETH = Convert.fromWei(balance.getBalance().toString(), Convert.Unit.ETHER).intValue();
                System.out.println("BlanceEth: " + blanceETH+" ether");
                txbalance.setText("餘額："+blanceETH+" ether");

              }

              }).start();

         }

    //QRcode掃描結果
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        IntentResult scanningResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, intent);
        if (scanningResult != null) {
            if (scanningResult.getContents() != null) {
                String scanContent = scanningResult.getContents();
                if (!scanContent.equals("")) {
                   // Toast.makeText(getApplicationContext(), "掃描內容: " + scanContent.toString(), Toast.LENGTH_LONG).show();
                    edAccount.setText(scanContent.toString());
                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, intent);
            Toast.makeText(getApplicationContext(), "發生錯誤", Toast.LENGTH_LONG).show();
        }
    }

    //中興幣合約餘額查詢
    public void contract_getbalance(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    BigInteger token_balance;

                    token_balance = token.balanceOf(address).send();
                    System.out.println("中興幣："+token_balance.divide(BigInteger.valueOf(10))+" CHUTK");
                    txbalance.setText("餘額："+token_balance.divide(BigInteger.valueOf(10))+" CHUTK");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    //合約初始化設定
    public void setting_contract(){
        BigInteger GAS_PRICE = BigInteger.valueOf(0);
        BigInteger GAS_LIMIT = BigInteger.valueOf(4_300_000);
         String contractAddr = "0xb559CB6a0402304f7C9A25F4CceAAFfe306e0631";
        token = FixedSupplyToken.load(
                contractAddr,
                MainActivity.admin,
                credentials,
                GAS_PRICE,
                GAS_LIMIT);
    }

    //合約Token轉帳
    public void contract_transfer(String account){
        dialog = ProgressDialog.show(TransferActivity.this,
                "交易中", "請等待...",true);
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {

                    token.transfer(account,BigInteger.valueOf(Long.parseLong(edAmount.getText().toString())*10)).send();
                    contract_getbalance();
                    edAccount.setText("");
                    edAmount.setText("");
                } catch (Exception e) {
                    e.printStackTrace();
                }
                dialog.dismiss();

            }

        }).start();
    }
}






