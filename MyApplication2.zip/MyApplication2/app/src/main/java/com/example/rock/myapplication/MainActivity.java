package com.example.rock.myapplication;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.web3j.crypto.CipherException;
import org.web3j.crypto.Credentials;
import org.web3j.crypto.RawTransaction;
import org.web3j.crypto.TransactionEncoder;
import org.web3j.crypto.WalletUtils;
import org.web3j.protocol.admin.Admin;
import org.web3j.protocol.admin.methods.response.NewAccountIdentifier;
import org.web3j.protocol.admin.methods.response.PersonalListAccounts;
import org.web3j.protocol.admin.methods.response.PersonalUnlockAccount;
import org.web3j.protocol.core.DefaultBlockParameter;
import org.web3j.protocol.core.DefaultBlockParameterName;
import org.web3j.protocol.core.Request;
import org.web3j.protocol.core.methods.request.Transaction;
import org.web3j.protocol.core.methods.response.EthEstimateGas;
import org.web3j.protocol.core.methods.response.EthGasPrice;
import org.web3j.protocol.core.methods.response.EthGetBalance;
import org.web3j.protocol.core.methods.response.EthGetTransactionCount;
import org.web3j.protocol.core.methods.response.EthSendTransaction;
import org.web3j.protocol.http.HttpService;
import org.web3j.tx.Transfer;
import org.web3j.utils.Convert;
import org.web3j.utils.Numeric;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.security.InvalidAlgorithmParameterException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.Security;
import java.util.List;
import java.util.concurrent.ExecutionException;

import static android.os.Environment.DIRECTORY_DOWNLOADS;

public class MainActivity extends AppCompatActivity {
    public static Admin admin;
    List<String> addressList;
    Button btn1;
    Button btn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        admin = Admin.build(new HttpService("http://140.120.55.86:8545"));
        setContentView(R.layout.activity_login_);

        try {
            setupBouncyCastle();
            setid();
            //transcation();
            // creatAccount();
            // Accountlist();
           // createWallet();
//            loadWallet();
            //transcation();
            //getBlanceOf();
        } catch(Exception e ){}




    }

    public void setid(){
        btn1 = findViewById(R.id.button);
        btn2 = findViewById(R.id.button2);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

    private void Accountlist(){
       new Thread(new Runnable() {
           @Override
           public void run() {

               try {
                   PersonalListAccounts personalListAccounts = admin.personalListAccounts().send();
                   addressList = personalListAccounts.getAccountIds();
                   System.out.println("account size " + addressList.size());
                   for (String address : addressList) {
                       System.out.println(address);
                   }
               } catch (IOException e) {
                   e.printStackTrace();
               }


           }
       }).start();
   }

    private void setupBouncyCastle() {
        final Provider provider = Security.getProvider(BouncyCastleProvider.PROVIDER_NAME);
        if (provider == null) {
            // Web3j will set up the provider lazily when it's first used.
            return;
        }
        if (provider.getClass().equals(BouncyCastleProvider.class)) {
            // BC with same package name, shouldn't happen in real life.
            return;
        }
        // Android registers its own BC provider. As it might be outdated and might not include
        // all needed ciphers, we substitute it with a known BC bundled in the app.
        // Android's BC has its package rewritten to "com.android.org.bouncycastle" and because
        // of that it's possible to have another BC implementation loaded in VM.
        Security.removeProvider(BouncyCastleProvider.PROVIDER_NAME);
        Security.insertProviderAt(new BouncyCastleProvider(), 1);
    }

    //帳戶間轉帳交易
    private void transcation(){
        BigInteger GAS_PRICE = BigInteger.valueOf(0);
        BigInteger GAS_LIMIT = BigInteger.valueOf(4_300_000);
        String address_to = "0x5b02d2123a00c46ea22047c3142BE20B2c6aab65";

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Credentials credentials = Credentials.create("a0b62ca6eb7db17fe0d03c65d1fc1c9ffe27256abf530688a0ea21b47136788e");
//                    Credentials credentials = WalletUtils.loadCredentials("123456",
//                            "/storage/emulated/0/Download/UTC--2019-05-28T09-32-35.0Z--9cdc6de0952107e3973e4dcb56cc1e0c8d2a850f.json");
                    EthGetTransactionCount ethGetTransactionCount = admin.ethGetTransactionCount(
                            "0x9cdc6de0952107e3973e4dcb56cc1e0c8d2a850f", DefaultBlockParameterName.LATEST).sendAsync().get();
                            BigInteger nonce = ethGetTransactionCount.getTransactionCount();
                //创建交易，这里是转0.5个以太币
                 BigInteger value = Convert.toWei("10", Convert.Unit.ETHER).toBigInteger();
                 RawTransaction rawTransaction = RawTransaction.createEtherTransaction(
                  nonce, GAS_PRICE, GAS_LIMIT, address_to, value);

                    byte[] signedMessage = TransactionEncoder.signMessage(rawTransaction, credentials);
                    String hexValue = Numeric.toHexString(signedMessage);

                    //发送交易
                     EthSendTransaction ethSendTransaction = admin.ethSendRawTransaction(hexValue).sendAsync().get();
                      String transactionHash = ethSendTransaction.getTransactionHash();
                      System.out.println("txhash:"+transactionHash);


                }  catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }


//                if (admin == null) return;
//                //开始发送0.01 =eth到指定地址
//                String address_from = "0xCa22B9B477c0199B3191e1541bb091b4E576AE4c";
//                String address_to = "0xc00f2E9b383a023f66F0CdE69623738992c0b942";
//                PersonalUnlockAccount personalUnlockAccount = null;
//                String txHash="";
//                try {
//                    BigInteger nonce = BigInteger.valueOf(10);
//                    personalUnlockAccount = admin.personalUnlockAccount(address_from, "123456").send();
//                    if (personalUnlockAccount.accountUnlocked()) {
//                        BigInteger value = Convert.toWei("10000", Convert.Unit.ETHER).toBigInteger();
//
//
//
//                    }
//                }catch (Exception e ){
//
//                }
            }

        }).start();


    }

    //離線交易簽名錢包，非在以太坊客戶端創立
    private void createWallet(){
        //String walletPath = getFilesDir().getAbsolutePath();
        // File walletDir  = new File(walletPath);

       final String password="123456";

       String path = Environment.getExternalStoragePublicDirectory(DIRECTORY_DOWNLOADS).getPath();
                    try {
                        File file =new File(path);


                        String fileName = WalletUtils.generateNewWalletFile(password,file);
                        System.out.println(file.getPath());

                    }
                    catch (NoSuchAlgorithmException e)
                    {
                        e.printStackTrace();
                    }
                    catch (NoSuchProviderException e)
                    {
                        e.printStackTrace();
                    }
                    catch (InvalidAlgorithmParameterException e)
                    {
                        e.printStackTrace();
                    }
                    catch (CipherException e)
                    {
                        e.printStackTrace();
                    }
                    catch (IOException e)
                    {
                        e.printStackTrace();
                    }
                }

    //讀取錢包位址，公私鑰
    private void loadWallet() throws IOException, CipherException {
       String password="123456";
       String walletPath="/storage/emulated/0/Download/UTC--2019-05-28T09-32-35.0Z--9cdc6de0952107e3973e4dcb56cc1e0c8d2a850f.json";
       Credentials credentials = WalletUtils.loadCredentials(password, walletPath);
       System.out.println("Address:"+credentials.getAddress());
       System.out.println("Public key:"+credentials.getEcKeyPair().getPublicKey().toString(16));
       System.out.println("Private key:"+credentials.getEcKeyPair().getPrivateKey().toString(16));


   }

   //直接在 client ethereum create account (keystore)
    private  void createAccount() throws IOException {
        new Thread(new Runnable() {
            @Override
            public void run() {
                NewAccountIdentifier newAccountIdentifier = null;
                try {
                    newAccountIdentifier = admin.personalNewAccount("123456").send();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                System.out.println("address id:"+newAccountIdentifier.getAccountId());
            }
        }).start();
   }
    //取得帳戶餘額

//    private void getBlanceOf() throws IOException {
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                if (admin == null) return;
//                String address = "0x9cdc6de0952107e3973e4dcb56cc1e0c8d2a850f";
//                //第二个参数：区块的参数，建议选最新区块
//                EthGetBalance balance = null;
//                try {
//                    balance = admin.ethGetBalance(address, DefaultBlockParameter.valueOf("latest")).send();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//                //格式转化 wei-ether
//                String blanceETH = Convert.fromWei(balance.getBalance().toString(), Convert.Unit.ETHER).toPlainString().concat(" ether");
//                System.out.println("BlanceEth: "+blanceETH);
//            }
//        }).start();

 //   }




}